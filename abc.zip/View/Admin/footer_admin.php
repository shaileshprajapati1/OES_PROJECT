	
    <!--footer-->
	<!-- <div class="footer">
	    <p>&copy; 2016 Novus Admin Panel. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">w3layouts</a></p>
	</div> -->
	<!--//footer-->
	</div>
	<!-- Classie -->
	<script src="<?php echo $this->URL; ?>Admin/js/classie.js"></script>
	<script>
	    var menuLeft = document.getElementById('cbp-spmenu-s1'),
	        showLeftPush = document.getElementById('showLeftPush'),
	        body = document.body;

	    showLeftPush.onclick = function() {
	        classie.toggle(this, 'active');
	        classie.toggle(body, 'cbp-spmenu-push-toright');
	        classie.toggle(menuLeft, 'cbp-spmenu-open');
	        disableOther('showLeftPush');
	    };


	    function disableOther(button) {
	        if (button !== 'showLeftPush') {
	            classie.toggle(showLeftPush, 'disabled');
	        }
	    }
	</script>
	<!--scrolling js-->
	<script src="<?php echo $this->URL; ?>Admin/js/jquery.nicescroll.js"></script>
	<script src="<?php echo $this->URL; ?>Admin/js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="<?php echo $this->URL; ?>Admin/js/bootstrap.js"> </script>
	</body>

	</html>