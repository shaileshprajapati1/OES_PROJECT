

<!-- about -->
<div class="about">
	<div class="container">
		<h3 class="heading">about us</h3>
		<div class="col-md-6 aboutleft">
			<h3>Welcome to E-Progress</h3>
			<p class="para1">Donec bibendum velit quis diam venenatis, vulputate aliquam sapien blandit. 
			Etiam dui massa, vehicula a convallis a, facilisis vitae neque.Pellentesque sit amet 
			odio quis libero eleifend congue at ac justo. Suspendisse posuere congue accumsan Vulputate aliquam sapien. </p>
			<p><i class="fa fa-check" aria-hidden="true"></i> Proin tempor pulvinar Vivamus nisi hendrerit et. </p>
			<p><i class="fa fa-check" aria-hidden="true"></i> Proin tempor pulvinar Vivamus nisi hendrerit et. </p>
			<p><i class="fa fa-check" aria-hidden="true"></i> Proin tempor pulvinar Vivamus nisi hendrerit et. </p>
			<p><i class="fa fa-check" aria-hidden="true"></i> Proin tempor pulvinar Vivamus nisi hendrerit et. </p>
		</div>
		<div class="col-md-6 aboutright">
			<img src="<?php echo $this->URL; ?>images/about.jpg" alt="" />
		</div>
		<div class="clearfix"></div>	
	</div>
</div>
<!-- //about -->

<!-- services -->
<div class="services jarallax">
	<div class="container">
		<div class="col-md-3 teamgrid1">
			<h3>Learning skills</h3>
			<h3>education</h3>
			<!-- <i class="fa fa-graduation-cap" aria-hidden="true"></i> -->
			<p> Proin tempor pulvinar sodalesaet. Vivamus lobortis nisi hendrerit mollis finibus ipsum et. </p>
		</div>
		<div class="col-md-3 teamgrid1">
			<h3>Central library</h3>
			<h3>Books</h3>
			<!-- <i class="fa fa-book" aria-hidden="true"></i> -->
			<p> Proin tempor pulvinar sodalesaet. Vivamus lobortis nisi hendrerit mollis finibus ipsum et. </p>
		</div>
		<div class="col-md-3 teamgrid1">
			<h3>Popular courses</h3>
			<h3>graduate</h3>
			<!-- <i class="fa fa-desktop" aria-hidden="true"></i> -->
			<p> Proin tempor pulvinar sodalesaet. Vivamus lobortis nisi hendrerit mollis finibus ipsum et. </p>
		</div>
		<div class="col-md-3 teamgrid1">
			<h3>Merit Awards</h3>
			<h3>prize</h3>
			<!-- <i class="fa fa-bus" aria-hidden="true"></i> -->
			<p> Proin tempor pulvinar sodalesaet. Vivamus lobortis nisi hendrerit mollis finibus ipsum et. </p>
		</div>
		<div class="clearfix"></div>	
	</div>
</div>
<!-- //services -->

<!-- team -->
<div class="team">
	<div class="container">
		<h3 class="heading">Teachers</h3>
		<div class="teamgrids">
			<div class="col-md-3 teamgrid1">
				<img src="<?php echo $this->URL; ?>images/t1.jpg" alt="" />
				<div class="teaminfo">
					<h3>Michael adam</h3>
					<div class="team-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-pinterest-p"></i></a>
					</div>
					<p><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Head Master</p>
					<p><i class="fa fa-phone" aria-hidden="true"></i> +02 133 4567</p>
					<p><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com"> mail@example.com</a></p>
				</div>
			</div>
			<div class="col-md-3 teamgrid1">
				<img src="<?php echo $this->URL; ?>images/t2.jpg" alt="" />
				<div class="teaminfo">
					<h3>Rebecca</h3>
					<div class="team-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-pinterest-p"></i></a>
					</div>
					<p><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Science Teacher</p>
					<p><i class="fa fa-phone" aria-hidden="true"></i> +02 133 4568</p>
					<p><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com"> mail@example1.com</a></p>
				</div>
			</div>
			<div class="col-md-3 teamgrid1">
				<img src="<?php echo $this->URL; ?>images/t3.jpg" alt="" />
				<div class="teaminfo">
					<h3>Sara</h3>
					<div class="team-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-pinterest-p"></i></a>
					</div>
					<p><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Maths Teacher</p>
					<p><i class="fa fa-phone" aria-hidden="true"></i> +02 133 4569</p>
					<p><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com"> mail@example2.com</a></p>
				</div>
			</div>
			<div class="col-md-3 teamgrid1">
				<img src="<?php echo $this->URL; ?>images/t4.jpg" alt="" />
				<div class="teaminfo">
					<h3>Leonardo pal</h3>
					<div class="team-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-linkedin"></i></a>
						<a href="#"><i class="fa fa-pinterest-p"></i></a>
					</div>
					<p><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Dean Officer</p>
					<p><i class="fa fa-phone" aria-hidden="true"></i> +02 133 4570</p>
					<p><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com"> mail@example3.com</a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //team -->
